//
//  WindowController.swift
//  NSSplitViewCollapse
//
//  Created by iDevFans on 16/7/20.
//  Copyright © 2016年 http://macdev.io. All rights reserved.
//

import Cocoa

class WindowController: NSWindowController {

    override func windowDidLoad() {
        super.windowDidLoad()
    
        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }
    
    @IBAction func openCloseAction(_ sender: AnyObject) {
        
        
    }

}
