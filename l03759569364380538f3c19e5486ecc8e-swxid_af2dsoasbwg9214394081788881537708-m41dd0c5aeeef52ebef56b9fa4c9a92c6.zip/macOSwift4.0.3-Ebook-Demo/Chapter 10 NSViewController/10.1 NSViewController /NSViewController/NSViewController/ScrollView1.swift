//
//  ScrollView1.swift
//  NSViewController
//
//  Created by iDevFans on 16/7/15.
//  Copyright © 2016年 http://macdev.io. All rights reserved.
//

import Cocoa

class ScrollView1: NSScrollView {

    override func updateConstraints(){
        
        Swift.print("ScrollView1 updateConstraints")
        super.updateConstraints()
    }
}
