//
//  Phone.swift
//  KVC
//
//  Created by iDevFans on 16/7/27.
//  Copyright © 2016年 macdev.io. All rights reserved.
//

import Cocoa

class Phone: NSObject {
    var office: String?
    var family: String?
    var mobile: String?
}
