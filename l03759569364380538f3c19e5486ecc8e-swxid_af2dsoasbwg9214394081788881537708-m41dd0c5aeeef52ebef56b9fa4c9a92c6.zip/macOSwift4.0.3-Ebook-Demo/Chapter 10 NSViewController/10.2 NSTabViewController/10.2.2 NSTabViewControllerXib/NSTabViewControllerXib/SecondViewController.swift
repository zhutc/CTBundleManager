//
//  SecondViewController.swift
//  NSTabViewControllerXib
//
//  Created by iDevFans on 16/7/18.
//  Copyright © 2016年 http://macdev.io. All rights reserved.
//

import Cocoa

class SecondViewController: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
   
        // Do view setup here.
    }
    
}
