//
//  LoadViewController.swift
//  CreateViewController
//
//  Created by iDevFans on 16/7/15.
//  Copyright © 2016年 http://macdev.io. All rights reserved.
//

import Cocoa

class LoadViewController: NSViewController {

    override func loadView() {
        //super.loadView()
        
        let frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        let view = NSView(frame: frame)
        
        self.view = view
        // Do view setup here.
    }
    
}
