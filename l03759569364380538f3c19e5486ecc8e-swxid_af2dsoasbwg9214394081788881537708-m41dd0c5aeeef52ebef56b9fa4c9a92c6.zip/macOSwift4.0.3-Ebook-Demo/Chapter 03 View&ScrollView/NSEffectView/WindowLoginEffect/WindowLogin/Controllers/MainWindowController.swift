//
//  MainWindowController.swift
//  WindowLogin
//
//  Created by zhaojw on 2017/11/3.
//  Copyright © 2017年 zhaojw. All rights reserved.
//

import Cocoa

class MainWindowController: NSWindowController {

    override func windowDidLoad() {
        super.windowDidLoad()
        self.window?.center()
    }
}
