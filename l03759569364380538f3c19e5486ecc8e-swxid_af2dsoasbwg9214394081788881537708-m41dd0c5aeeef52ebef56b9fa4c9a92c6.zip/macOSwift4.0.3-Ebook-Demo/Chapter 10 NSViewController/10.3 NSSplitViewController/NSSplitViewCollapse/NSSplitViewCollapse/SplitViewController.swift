//
//  SplitViewController.swift
//  NSSplitViewCollapse
//
//  Created by iDevFans on 16/7/20.
//  Copyright © 2016年 http://macdev.io. All rights reserved.
//

import Cocoa

class SplitViewController: NSSplitViewController {

}
