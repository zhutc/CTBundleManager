//
//  AppDelegate.swift
//  PageScrollView
//
//  Created by zhaojw on 2017/11/11.
//  Copyright © 2017年 zhaojw. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

