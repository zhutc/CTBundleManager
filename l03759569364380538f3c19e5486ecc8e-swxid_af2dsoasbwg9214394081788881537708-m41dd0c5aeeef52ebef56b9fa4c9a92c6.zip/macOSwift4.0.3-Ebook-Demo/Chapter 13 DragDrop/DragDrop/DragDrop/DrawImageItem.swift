//
//  DrawImageItem.swift
//  DragDrop
//
//  Created by iDevFans on 16/7/25.
//  Copyright © 2016年 http://macdev.io. All rights reserved.
//

import Cocoa

final class DrawImageItem: NSObject {
    var image: NSImage?
    var location: NSPoint?
}

