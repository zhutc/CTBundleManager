//
//  AppDelegate.swift
//  iCloud
//
//  Created by iDevFans on 16/8/8.
//  Copyright © 2016年 macdev. All rights reserved.
//

import Cocoa


//@property(nonatomic,strong)NSFileManager *fileManager;
//@property(nonatomic,strong)NSURL *ubiquityContainer;
//@property(nonatomic,strong)id ubiquityToken;
//@property(nonatomic,strong)NSUbiquitousKeyValueStore *keyValueStore;

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ aNotification: Notification) {
       
       

    }
    
    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

